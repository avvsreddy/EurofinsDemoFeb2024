﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lab9
{
    class Roles
    {
        /// <summary>
        /// Fields of the class which are read only. Can't be assigned values again
        /// </summary>
        
    }
}
